extends CharacterBody2D
class_name AIPlayer

@onready var boss: Boss = $"../Boss"

const SPEED = 100.0 #300
const JUMP_VELOCITY = -400.0
const DODGE_SPEED = 150.0 #500
const DODGE_DURATION = 0.5  # Should match your roll animation length
const DODGE_COOLDOWN = 0  # Prevent spamming
const KNOCKBACK_FORCE = 300.0
const HIT_COOLDOWN = 0.2
const MAX_HEALTH = 100
const ATTACK_DAMAGE = 10
const DODGE_INVULNERABILITY_DURATION = 0.5

@onready var animated_sprite: AnimatedSprite2D = $AnimatedSprite2D
@onready var attack_hitbox: Area2D = $hitarea
@onready var health_bar: ProgressBar = $HealthBar
@onready var ai_controller: Node2D = $AIController2D


var is_attacking := false
var is_dodging := false
var can_dodge := true
var dodge_direction := 1.0  # Default to right if no input
var current_health := MAX_HEALTH
var is_invulnerable := false
var took_damage_this_frame := false
var successful_dodge_this_frame := false
var can_flip :=true
var is_close_to_boss :=false



func _ready():
	health_bar.max_value = MAX_HEALTH
	health_bar.value = current_health
	attack_hitbox.monitoring = false
	ai_controller.init(self)

func _physics_process(delta: float) -> void:
	if is_dodging:
		$".".collision_layer=2
		$".".collision_mask=4
	else:
		$".".collision_layer=1
		$".".collision_mask=1
	if current_health <= 0:
		set_physics_process(false)
		animated_sprite.play("death")
		await animated_sprite.animation_finished
		die()
		return
	# Get movement input
	var direction: float = ai_controller.move
	
	# Update facing direction
	if direction != 0 and can_flip:
		animated_sprite.flip_h = direction < 0
		dodge_direction = direction  # Store last direction for dodge
		if direction<0:
			$hitarea.scale = Vector2(-1,1)
		if direction>0:
			$hitarea.scale = Vector2(1,1)

	# Apply gravity if not dodging
	if not is_on_floor() and not is_dodging:
		velocity += get_gravity() * delta

	# Normal movement (when not attacking or dodging)
	if not (is_attacking or is_dodging):
		if direction == 0:
			animated_sprite.play("Idle")
			velocity.x = move_toward(velocity.x, 0, SPEED)
		else:
			start_run(direction)

	# Attack logic
	if ai_controller.attack and not is_attacking and not is_dodging:
		start_attack()

	# Dodge/Roll logic
	if ai_controller.dodge and not is_dodging and not is_attacking and can_dodge:
		start_dodge()
	if (position.distance_to(boss.position) < 30) and is_dodging:
		successful_dodge_this_frame = true

	move_and_slide()
	took_damage_this_frame = false
	successful_dodge_this_frame = false


func start_run(direction):
	animated_sprite.play("Run") 
	velocity.x = direction * SPEED
	
func start_dodge():
	is_dodging = true
	can_dodge = false
	can_flip = false
	velocity.x = dodge_direction * DODGE_SPEED
	velocity.y = 0  # Optional: disable gravity during dodge
	animated_sprite.play("roll") 
	
	# Wait for dodge to complete
	await get_tree().create_timer(DODGE_DURATION).timeout
	is_dodging = false
	
	# Start cooldown
	await get_tree().create_timer(DODGE_COOLDOWN).timeout
	can_dodge = true
	can_flip = true
	

func start_attack():
	is_attacking = true
	can_flip = false
	velocity.x = 0
	animated_sprite.play("Attack2")
	# Wait a brief moment before activating hitbox
	await get_tree().create_timer(0.2).timeout
	# Only activate if we're still attacking (animation wasn't interrupted)
	if is_attacking:
		attack_hitbox.monitoring = true
		print("Hitbox activated: ", attack_hitbox.monitoring)
	# Wait for animation to finish
	await animated_sprite.animation_finished
	# Deactivate hitbox when attack completes
	attack_hitbox.monitoring = false
	is_attacking = false
	can_flip = true
	print("Hitbox deactivated: ", attack_hitbox.monitoring)
	
func take_damage(damage: int, attacker_position: Vector2):
	if is_invulnerable or is_dodging:
		return
	
	current_health -= damage
	health_bar.value = current_health
	
	# Apply knockback
	var knockback_direction = sign(position.x - attacker_position.x)
	velocity.x = knockback_direction * KNOCKBACK_FORCE*0.1
	set_physics_process(false)
	animated_sprite.play("hit")
	await animated_sprite.animation_finished
	set_physics_process(true)
	
	# Flash effect when hit
	modulate = Color.RED
	await get_tree().create_timer(0.1).timeout
	modulate = Color.WHITE
func die():
	#$".".queue_free()
	set_physics_process(true)
	position = Vector2(-113, 82)
	current_health = MAX_HEALTH
	health_bar.value = current_health
	


func _on_hitarea_body_entered(body):
	if body.has_method("take_damage") and body != self:
		print("---------------gotcha---------------")
		body.take_damage(ATTACK_DAMAGE, position)
		took_damage_this_frame = true
		


func _on_looker_body_entered(body):
	if body.has_method("take_damage") and body != self:
		print("++++++++++++++++++close++++++++++++++++++")
		is_close_to_boss = true


func _on_looker_body_exited(body):
	if body.has_method("take_damage") and body != self:
		print("++++++++++++++++++NOT CLOSE++++++++++++++++++")
		is_close_to_boss = false
